module.exports = function (data) {
  return `
<footer>
  <p>
    Made with
    <a href="https://github.com/lit/lit-element-starter-ts">lit-starter-ts</a>
  </p>
</footer>`;
};
